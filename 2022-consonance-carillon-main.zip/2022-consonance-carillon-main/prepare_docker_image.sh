apt-get install -y libsndfile1
